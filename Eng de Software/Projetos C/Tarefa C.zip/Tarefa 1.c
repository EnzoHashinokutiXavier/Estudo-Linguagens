#include <stdio.h>

void main()
{
    float salario, financeamento;

    printf("Digite seu salario : ");
    scanf("%f", &salario);

    printf("Digite o valor do financeamento :");
    scanf("%f", &financeamento);

    if (financeamento <= (salario * 5))
        printf("Financeamento aceito");
    else
        printf("Financeamento negado");
}
