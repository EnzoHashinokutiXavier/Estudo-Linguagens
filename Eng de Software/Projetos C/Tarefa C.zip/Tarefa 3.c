#include <stdio.h>

void main()
{
    float litros, preco_l, valor_final;
    preco_l = 5.40;

    printf("Digite a quantia em litros a ser vendido : ");
    scanf("%f", &litros);

    if (litros < 20)
        valor_final = (litros * preco_l) * 0.96;
    else
        valor_final = (litros * preco_l) * 0.94;

    printf("O valor a ser cobrado sera %.2f", valor_final);

}
