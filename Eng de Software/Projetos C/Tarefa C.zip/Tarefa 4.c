#include <stdio.h>

void main()
{
    int quant_max, quant_min, quant_atual;
    float quant_media;

    printf("Digite a quantia atual em estoque : ");
    scanf("%d", &quant_atual);

    printf("Digite a quantia maxima de estoque : ");
    scanf("%d", &quant_max);

    printf("Digite a quantia minima de estoque : ");
    scanf("%d", &quant_min);

    quant_media = (quant_max + quant_min)/2;

    if (quant_atual > quant_media)
        printf("Nao efetuar compra");
    else
        printf("Efetuar compra");
}
