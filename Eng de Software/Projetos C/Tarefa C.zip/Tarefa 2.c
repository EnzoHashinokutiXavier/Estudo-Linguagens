#include <stdio.h>

void main()
{
    float salario, reajuste;
    int anos;

    printf("Digite seu tempo de servisso em anos : ");
    scanf("%d", &anos);

    printf("Digite o seu salario atual : ");
    scanf("%f", &salario);

    if (anos < 10)
        reajuste = salario * 1.08;
    else
        reajuste = salario * 1.10;

    printf("O seu salario reajustado sera de RS%.2f", reajuste);
}
