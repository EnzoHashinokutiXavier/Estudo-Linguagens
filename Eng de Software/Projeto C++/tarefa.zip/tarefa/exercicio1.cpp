#include<iostream>

using namespace std;

struct pessoa{
    float salario;
    int idade;
    char sexo;
    int filhos;
};

int main(){
    int i, ch = 0, cm = 0, cf = 0;
    float mediaMulheres = 0, mediaHomens = 0, mediaFilhos = 0;
    pessoa lista[10];

    for (i = 0; i < 10; i++){
        cout<<"Informe o salario : ";
        cin >> lista[i].salario;
        cout<<"Informe a idade : ";
        cin >> lista[i].idade;
        cout<<"Informe o sexo m/f : ";
        cin >> lista[i].sexo;
        cout<<"Informe o numero de filhos: ";
        cin >> lista[i].filhos;
    }

    for (i = 0; i < 10; i++){
        if (lista[i].sexo == 'f'){
            mediaMulheres += lista[i].salario;
            cm++;
        }
        if (lista[i].sexo == 'm'){
            mediaHomens += lista[i].salario;
            ch++;
        }
        mediaFilhos += lista[i].filhos;
    }
    mediaMulheres = mediaMulheres / cm;
    mediaHomens = mediaHomens / ch;
    mediaFilhos = mediaFilhos / 10;

    cout<<"Media de salario das mulheres : "<<mediaMulheres<<endl;
    cout<<"Media de salario dos homens : "<<mediaHomens<<endl;
    cout<<"Media de filhos : "<<mediaFilhos<<endl;

}